'use strict'

exports.handler = async (event, context) => {
  const response = {
    statusCode: 200,
    headers: {
      "Content-Type": "text/plain"
    },
    body: "Hello, Mia Demo Serverless"
  };
  return response;
};


